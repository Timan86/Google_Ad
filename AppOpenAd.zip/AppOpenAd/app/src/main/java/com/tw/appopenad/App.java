package com.tw.appopenad;

import android.app.Application;
import android.content.Context;

import com.google.android.gms.ads.InterstitialAd;
import com.google.android.gms.ads.MobileAds;
import com.google.android.gms.ads.initialization.InitializationStatus;
import com.google.android.gms.ads.initialization.OnInitializationCompleteListener;

public class App extends Application {

    private InterstitialAd mInterstitialAd;
    private static AppOpenManager appOpenManager;

    private static Context mContext;

    public static Context getAppContext() {
        return mContext;
    }

    @Override
    public void onCreate() {
        super.onCreate();
        mContext = (Context)this;
        initAds();
    }

    private void initAds() {
        MobileAds.initialize(this, new OnInitializationCompleteListener() {
            @Override
            public void onInitializationComplete(InitializationStatus initializationStatus) {
            }
        });
        appOpenManager = new AppOpenManager(this);

        // insert ad
        mInterstitialAd = new InterstitialAd(this);
        mInterstitialAd.setAdUnitId(true ? getString(R.string.test_interstitial_ad) : getString(R.string.release_insert_image_video));
    }

    public InterstitialAd getInterstitialAd() {
        return mInterstitialAd;
    }
}
